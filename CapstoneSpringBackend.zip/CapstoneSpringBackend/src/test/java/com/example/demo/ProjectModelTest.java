package com.example.demo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;

import org.junit.Test;
import org.spockframework.runtime.SpockAssertionError;

import com.example.demo.model.Profile;
import com.example.demo.model.Projects;

public class ProjectModelTest {
	
	@Test
	public void testgetProjectId() {
		 Projects project = new Projects(1,"Lokesh@gmail.com","projecrtname","projectdescription","five years");
		 Projects pro = new Projects(1,"Lokesh@gmail.com","projecrtname","projectdescription","five years");
		 assertEquals(pro.getProjectId(),project.getProjectId());
		
	}

	@Test
	public void testSetProjectId() {
		 Projects project = new Projects(1,"Lokesh@gmail.com","projecrtname","projectdescription","five years");
		 project.setProjectId(3);
		 Projects pro = new Projects(1,"Lokesh@gmail.com","projecrtname","projectdescription","five years");
		 pro.setProjectId(3);
		 assertEquals(project.getProjectId(), pro.getProjectId());
		
	}
	
	@Test
	public void testgetEmailId() {
		Projects project = new Projects(1,"Lokesh@gmail.com","projecrtname","projectdescription","five years");
		assertEquals("Lokesh@gmail.com",project.getEmailId());
	}
	@Test
	public void testSetEmailId() {
		Projects project = new Projects(1,"rakesh@gmail.com","projecrtname","projectdescription","five years");
		project.setEmailId("Lokesh@gmail.com");
		assertEquals("Lokesh@gmail.com",project.getEmailId());
	}
	@Test
	public void testgetProjectName() {
		Projects project = new Projects(1,"Lokesh@gmail.com","projecrtname","projectdescription","five years");
		assertEquals("projecrtname",project.getProjectName());
	}
	@Test
	public void testSetProjectName() {
		Projects project = new Projects(1,"rakesh@gmail.com","projecrtname","projectdescription","five years");
		project.setProjectName("name");;
		assertEquals("name",project.getProjectName());
	}
	
	@Test
	public void testgetProjecTDesc() {
		Projects project = new Projects(1,"Lokesh@gmail.com","projecrtname","projectdescription","five years");
		assertEquals("projectdescription",project.getProjectDesc());
	}
	@Test
	public void testSetProjecTDesc() {
		Projects project = new Projects(1,"Lokesh@gmail.com","projecrtname","projectdescription","five years");
		project.setProjectDesc("description");
		assertEquals("description",project.getProjectDesc());
	}
	@Test
	public void testgetProjecTDuration() {
		Projects project = new Projects(1,"Lokesh@gmail.com","projecrtname","projectdescription","five years");
		assertEquals("five years",project.getDuration());
	}
	@Test
	public void testSetProjecTDuration() {
		Projects project = new Projects(1,"Lokesh@gmail.com","projecrtname","projectdescription","five years");
		project.setDuration("two years");
		assertEquals("two years",project.getDuration());
	}
	
	@Test
	public void TestNonParametarizedConstructor() {
Projects project= new Projects();
		
		String expectedemail=null;
		assertEquals(expectedemail,project.getEmailId());
	}
	
	
	@Test
	public void TestToString() {
		Projects project = new Projects(1,"Lokesh@gmail.com","projecrtname","projectdescription","five years");
		String expected= "Projects [projectId=" +1 + ", emailId=" + "Lokesh@gmail.com" + ", projectName=" + "projecrtname"
				+ ", projectDesc=" + "projectdescription" + ", duration=" + "five years"+ "]";
		assertEquals(expected,project.toString());
	}
	
}
