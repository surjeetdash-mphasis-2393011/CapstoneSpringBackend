package com.example.demo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.example.demo.model.Profile;
import com.example.demo.model.Projects;
import com.example.demo.model.Users;
import com.example.demo.repository.ProjectsRepository;
import com.example.demo.repository.UsersRepository;
import com.example.demo.service.ProjectsService;
import com.example.demo.service.UsersService;

@RunWith(MockitoJUnitRunner.class)
public class UserServiceTest {
	
	@InjectMocks
	private UsersService userservice;
	
	@Mock
	private UsersRepository userrepository;
	
	@Test
	public void TestUpdate() throws ParseException {
		 Users users = new Users(1,"srujanagg@gmail.com","123*");
		 userservice.update(users);
	     
		    verify(userrepository, times(1)).save(users);
		
	}

	@Test
	public void TestCreate() throws ParseException {
		Users users = new Users(1,"srujanagg@gmail.com","123*");
		 userservice.create(users);
	     
		    verify(userrepository, times(1)).save(users);
		
	}
	@Test
	public void TestDelete() throws ParseException {
		Users users = new Users(1,"srujanagg@gmail.com","123*");
		 userservice.delete(users);;
	     
		    verify(userrepository, times(1)).delete(users);
		
	}
//	@Test
//	public void TestLoginvalidate() {
//		 List<Users> list = new ArrayList<Users>();
//		Users users = new Users(1,"srujanagg@gmail.com","123*");
//		Users users2 = new Users(2,"srujanagg@gmail.com","143*");
//		list.add(users);
//		list.add(users2);
////		when(userrepository.loginValidate("srujanagg@gmail.com","123*").size()==1? 1 :0).thenReturn(1);
//	       int a =userservice.loginValidate("srujanagg@gmail.com", "123*");
////	         assertNotEquals(1, a);
//	        verify(userrepository, times(1)).loginValidate("srujanagg@gmail.com","123*");
//	}
	   @Test
	    public void testRead()
	    
	    {
	    	
	         List<Users> list = new ArrayList<>();
	            Users userOne = new Users(1, "rakshit123@gmail.com", "1234");
	            
	             
	            list.add(userOne);
	            
	             
	            when(userrepository.findAll()).thenReturn(list);
	             
	            //test
	            List<Users> usersList = userservice.read();
	             
	            assertEquals(list,usersList);
	            verify(userrepository, times(1)).findAll();
	            
	            
	    }
	   @Test
	    public void TestfetchUsersByEmail()
	    {

		   Users userOne = new Users(1, "rakshit123@gmail.com", "1234");
		       

	        when(userrepository.findByEmailId("rakshit123@gmail.com")).thenReturn(userOne);
	         
	        Users usertwo =  userservice.fetchUsersByEmail("rakshit123@gmail.com");
	        assertEquals(userOne, usertwo);
	        verify(userrepository, times(1)).findByEmailId("rakshit123@gmail.com");
	
	        
	    }

}
