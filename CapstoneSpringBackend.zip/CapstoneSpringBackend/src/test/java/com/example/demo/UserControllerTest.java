package com.example.demo;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

 

import java.util.ArrayList;
import java.util.List;

 

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.example.demo.controller.UsersController;
import com.example.demo.model.Users;
import com.example.demo.service.UsersService;

 
@RunWith(MockitoJUnitRunner.class)
public class UserControllerTest
{
    
    
    @InjectMocks
     UsersController usersController;
    
    @Mock
    UsersService usersService;
    
//    @Before
//    void setUp() throws Exception
//    {
//        MockitoAnnotations.initMocks(this);
//    }
    
    
    @Test
    public void testCreateNewUser() throws Exception
    {
        Users users = new Users(1,"srujanagg@gmail.com","123*");
        
        usersController.addUsers(users);
         
        verify(usersService, times(1)).create(users);
    }
//    @Test
//    public void testCreateNewUserException() throws Exception
//    {
//        Users users = new Users(1,"srujanagg@gmail.com","123*");
//        Users users2 = new Users(1,"srujanagg@gmail.com","123*");
//        when(usersService.create(users)).thenReturn(users);
//        when(usersService.create(users2)).thenThrow(new Exception());
//        usersController.addUsers(users);
//         
//        verify(usersService, times(1)).create(users);
//    }
    @Test
    public void testLogin() throws Exception
    {
        Users users = new Users(1,"srujanagg@gmail.com","123*");
        when(usersService.loginValidate(users.getEmailId(), users.getPassword())).thenReturn(1);
       int a = usersController.login("srujanagg@gmail.com", "123*");
         assertEquals(1, a);
        verify(usersService, times(1)).loginValidate("srujanagg@gmail.com","123*");
    }
    @Test
    public void testLoginFalse() throws Exception
    {
        Users users = new Users(1,"srujanagg@gmail.com","123*");
        when(usersService.loginValidate(users.getEmailId(), users.getPassword())).thenReturn(0);
       int a = usersController.login("srujanagg@gmail.com", "123*");
         assertEquals(0, a);
        verify(usersService, times(1)).loginValidate("srujanagg@gmail.com","123*");
    }

    
    @Test
    public void testGetAllUsers()
    
    {
    	
         List<Users> list = new ArrayList<>();
            Users userOne = new Users(1, "rakshit123@gmail.com", "1234");
            
             
            list.add(userOne);
            
             
            when(usersService.read()).thenReturn(list);
             
            //test
            List<Users> usersList = usersController.getAllUsers();
             
            assertEquals(list,usersList);
            verify(usersService, times(1)).read();
            
            
    }
    
    @Test
    public void testGetAllUsersNegative()
    
    {
    	
         List<Users> list = new ArrayList<>();
            Users userOne = new Users(1, "rakshit123@gmail.com", "1234");
            
             
            list.add(userOne);
            
             
            when(usersService.read()).thenReturn(list);
             
            //test
            List<Users> usersList = usersController.getAllUsers();
             
            assertNotEquals(2,usersList.size());
            verify(usersService, times(1)).read();
            
            
    }
    
    
    
}