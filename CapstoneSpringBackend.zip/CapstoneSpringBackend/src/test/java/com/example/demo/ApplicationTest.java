package com.example.demo;

import org.junit.Test;

public class ApplicationTest {
//	 @Test
//	   public void main() {
//		 CapstoneSpringBackendApplication.main(new String[] {});
//	   }
}

