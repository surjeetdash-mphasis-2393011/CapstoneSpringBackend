package com.example.demo;


import static org.hamcrest.CoreMatchers.any;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.example.demo.controller.ProfileController;
import com.example.demo.model.Profile;
import com.example.demo.service.ProfileService;


@RunWith(MockitoJUnitRunner.class)
public class ProfileControllerTest {
	
	@InjectMocks
	private ProfileController pcontroller;

	@Mock
	private ProfileService pservice;

	@Before
	public void setUp() throws Exception
	{
		MockitoAnnotations.initMocks(this);
	}


	@Test
	public void CreateProfileTest() throws Exception, ParseException
	{
		SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
		Profile profile = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
	    
	    pcontroller.createProfile(profile);
	     
	    verify(pservice, times(1)).insert(profile);
	}
	
	
	
	@Test
	public void ProfilesList() throws ParseException
	{
		 List<Profile> list = new ArrayList<Profile>();
		 
		 	SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
			Profile one = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
			Profile two = new Profile("srujana@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
		      
	        
	         
	        list.add(one);
	        list.add(two);
	        
	         
	        when(pservice.getall()).thenReturn(list);
	         
	        //test
	        List<Profile> profileList = pcontroller.getAllProfiles();
	         assertEquals(profileList, list);
//	        assertEquals(1,usersList.size());
	        verify(pservice, times(1)).getall();
	}
	
	@Test
	public void ProfilesListTestNegative() throws ParseException
	{
		 List<Profile> list = new ArrayList<Profile>();
		 
		 	SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
			Profile one = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
			Profile two = new Profile("srujana@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
		      
	        
	         
	        list.add(one);
	        list.add(two);
	        
	         
	        when(pservice.getall()).thenReturn(list);
	         
	        //test
	        List<Profile> profileList = pcontroller.getAllProfiles();
	       
	        assertNotEquals(3,profileList.size());
	        verify(pservice, times(1)).getall();
	}
	
	
	
	 @Test
	    public void getProfileByIdTest() throws ParseException
	    {
		 SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");

		 System.out.println(sdf);
		 Profile profile= new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("2021-04-09"),"1");
	        when(pservice.findbyId("srujanagg@gmail.com")).thenReturn(profile);
	         
	        Profile profileatcontroller = pcontroller.getbyId("srujanagg@gmail.com");
	         assertEquals(profile, profileatcontroller);
	      

	        
	    }

	 @Test
	    public void getProfileByIdTestNegative() throws ParseException
	    {
		 SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");

		 System.out.println(sdf);
		 Profile profile= new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("2021-04-09"),"1");
	        when(pservice.findbyId("srujanagg@gmail.com")).thenReturn(profile);
	         
	        Profile profileatcontroller = pcontroller.getbyId("srujanagg@gmail.com");
	        Profile profile2= new Profile("srujangg@gmail.com","Srujan","Gundpu",240922,sdf.parse("2021-05-09"),"1");
	         assertNotEquals(profile2, profileatcontroller);
	      

	        
	    }
	 


	 
	 
	 @Test
		public void UpdateProfileTest() throws Exception, ParseException
		{
			SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
//			Date date = new Date();
			Profile profile = new Profile("srujanagg@gmail.com","Srujana","G",2409229,sdf.parse("1998-09-04"),"2");
		    
		    pcontroller.updateprofile(profile);
		     
		    verify(pservice, times(1)).update(profile);
		    
		}
	 @Test(expected=Exception.class)
	 public void TestGetById() throws ParseException {
		 SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
//			Date date = new Date();
			Profile profile = new Profile("srujanagg@gmail.com","Srujana","G",2409229,sdf.parse("1998-09-04"),"2");
		    
		 when(pservice.findbyId(null)).thenThrow(Exception.class);
	        when(pservice.findbyId("srujanagg@gmail.com")).thenReturn(profile);

	        Profile profile1 = pcontroller.getbyId("srujanagg@gmail.com");
	        Profile profile2 = pcontroller.getbyId(null);
	        assertEquals(profile, profile1);
//	        verify(pservice, times(1)).findbyId(null);
//	        verify(pservice, times(1)).findbyId("srujanagg@gmail.com");
	 }
		


}
