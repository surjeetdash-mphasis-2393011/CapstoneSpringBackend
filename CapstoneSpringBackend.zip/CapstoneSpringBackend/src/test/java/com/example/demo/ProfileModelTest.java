package com.example.demo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotSame;

import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.Test;

import com.example.demo.model.Profile;

public class ProfileModelTest {
	
	@Test
	public void testgetEmailId() throws ParseException {
		SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
		Profile profile = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
	     assertEquals("srujanagg@gmail.com", profile.getEmailId());
	}
	
	@Test
	public void testsetEmailId() throws ParseException {
		SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
		Profile profile = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
		   profile.setEmailId("rujanagg@gmail.com");
	     assertEquals("rujanagg@gmail.com", profile.getEmailId());
	}
	
	@Test
	public void testgetFirstName() throws ParseException {
		SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
		Profile profile = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
	     assertEquals("Srujana", profile.getFirstName());
	}
	
	@Test
	public void testsetFirstName() throws ParseException {
		SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
		Profile profile = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
		   profile.setFirstName("rujana");;
	     assertEquals("rujana", profile.getFirstName());
	}
	
	@Test
	public void testgetLastName() throws ParseException {
		SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
		Profile profile = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
	     assertEquals("Gundapu", profile.getLastName());
	}
	
	@Test
	public void testsetLasstName() throws ParseException {
		SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
		Profile profile = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
		   profile.setLastName("undapu");;
	     assertEquals("undapu", profile.getLastName());
	}
	@Test
	public void testgetEmployeeId() throws ParseException {
		SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
		Profile profile = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
		Profile profile2 = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
	     assertEquals(profile2.getEmployeeId(), profile.getEmployeeId());
	}
	
	@Test
	public void testsetEmployeeId() throws ParseException {
		SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
		Profile profile = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409228,sdf.parse("1998-09-04"),"1");
		   profile.setEmployeeId(2409229);
		   Profile profile2 = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409228,sdf.parse("1998-09-04"),"1");
		   profile2.setEmployeeId(2409229);
		   
	     assertEquals(profile2.getEmployeeId(), profile.getEmployeeId());
	}
	
	
	@Test
	public void testgetDateOfBirth() throws ParseException {
		SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
		Profile profile = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
	     assertEquals(sdf.parse("1998-09-04"), profile.getDateOfBirth());
	}
	
	@Test
	public void testsetdateofbirth() throws ParseException {
		SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
		Profile profile = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
		   profile.setDateOfBirth(sdf.parse("2000-09-05"));
	     assertEquals(sdf.parse("2000-09-05"), profile.getDateOfBirth());
	}
	@Test
	public void testgetLocationId() throws ParseException {
		SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
		Profile profile = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
	     assertEquals("1", profile.getLocationId());
	}
	
	@Test
	public void testsetLocationId() throws ParseException {
		SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
		Profile profile = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
		   profile.setLocationId("2");;
	     assertEquals("2", profile.getLocationId());
	}
	
	
	@Test
	public void TestTostring() throws ParseException {
		SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
		Profile profile = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
		 
		  String expected="Profile [emailId=" + "srujanagg@gmail.com" + ", firstName=" +"Srujana" + ", lastName=" + "Gundapu" + ", employeeId="
					+ 2409229 + ", dateOfBirth=" + sdf.parse("1998-09-04") + ", locationId=" + "1" + "]";
		
		assertEquals(expected, profile.toString());
		
		
	}
	
	@Test
	public void TestNonParameterizedConstructor() {
		Profile profile= new Profile();
		
		String expectedemail=null;
		assertEquals(expectedemail,profile.getEmailId());
		
	}
	

}
