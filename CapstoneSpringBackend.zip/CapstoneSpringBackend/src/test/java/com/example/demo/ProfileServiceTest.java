package com.example.demo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.example.demo.model.Profile;
import com.example.demo.repository.ProfileRepository;
import com.example.demo.service.ProfileService;
@RunWith(MockitoJUnitRunner.class)
public class ProfileServiceTest {
	@InjectMocks
	private ProfileService profileservice;
	
	@Mock
	private ProfileRepository profilerepository;
	
@Test
public void TestInsert() throws ParseException {
	SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
	Profile profile = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
	 profileservice.insert(profile);
     
	    verify(profilerepository, times(1)).save(profile);
	
}
@Test
public void TestFindById() throws ParseException {
	SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
	Profile profile = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
	when(profilerepository.findById("srujanagg@gmail.com")).thenReturn(Optional.of(profile));
	Profile profile2 = profileservice.findbyId("srujanagg@gmail.com");
	assertNotNull(profile2);
}
@Test
public void TestUpdate() throws ParseException {
	SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
	Profile profile = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
	 profileservice.update(profile);
     
	    verify(profilerepository, times(1)).save(profile);
	
}
@Test
public void TestDelete() throws ParseException {
	SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
	Profile profile = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
	 profileservice.delete(profile);
     
	    verify(profilerepository, times(1)).delete(profile);
	
}
@Test
public void TestGetAll() throws ParseException
{
	 List<Profile> list = new ArrayList<Profile>();
	 
	 	SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd");
		Profile one = new Profile("srujanagg@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
		Profile two = new Profile("srujana@gmail.com","Srujana","Gundapu",2409229,sdf.parse("1998-09-04"),"1");
	      
        
         
        list.add(one);
        list.add(two);
        
         
        when(profilerepository.findAll()).thenReturn(list);
         
        //test
        List<Profile> profileList = profileservice.getall();
         assertEquals(profileList.size(), list.size());

        verify(profilerepository, times(1)).findAll();
}

	
}
