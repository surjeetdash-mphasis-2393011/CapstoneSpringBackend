package com.example.demo;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.example.demo.controller.ProjectsController;
import com.example.demo.model.Projects;
import com.example.demo.service.ProjectsService;
@RunWith(MockitoJUnitRunner.class)
public class ProjectsControllerTest {
	 @InjectMocks
	    ProjectsController projectController;
	     
	    @Mock
	    ProjectsService  projectService;
	    
//	    @Before
//	    public void init() {
//	        MockitoAnnotations.initMocks(this);
//	    }
           
	    @Test
	    public void createProjectsTest()
	    {
	        Projects pro = new Projects(1,"Lokesh@gmail.com","projecrtname","projectdescription","five years");
	         
	        projectController.createProjects(pro);
	         
	        verify(projectService, times(1)).createProjet(pro);
	    }
	    
	    @Test
	    public void getAllProjectsTest()
	    {
	        List<Projects> list = new ArrayList<Projects>();
	        Projects project = new Projects(1,"Lokesh@gmail.com","projecrtname","projectdescription","five years");
	       
	         
	        list.add(project);
	       
	         
	        when(projectService.getAllProjects()).thenReturn(list);
	         
	        //test
	        List<Projects> projectList = projectController.getallprojects();
	         
	        assertEquals(1, projectList.size());
	        verify(projectService, times(1)).getAllProjects();
	    }
	    @Test
	    public void getAllProjectsTestNegative()
	    {
	        List<Projects> list = new ArrayList<Projects>();
	        Projects project = new Projects(1,"Lokesh@gmail.com","projecrtname","projectdescription","five years");
	       
	         
	        list.add(project);
	       
	         
	        when(projectService.getAllProjects()).thenReturn(list);
	         
	        //test
	        List<Projects> projectList = projectController.getallprojects();
	         
	        assertNotEquals(2, projectList.size());
	        verify(projectService, times(1)).getAllProjects();
	    }
	    
	    
	    @Test
	    public void getProjectByIdTest()
	    {
	    	 List<Projects> list = new ArrayList<Projects>();
		        Projects project1 = new Projects(1,"Lokesh@gmail.com","projecrtname1","projectdescription","five years");
		        Projects project2 = new Projects(2,"Lokesh@gmail.com","projecrtname2","projectdescription","five years");
		        list.add(project1);
		        list.add(project2);
	        when(projectService.getByEmailId("Lokesh@gmail.com")).thenReturn(list);
	         
	        List<Projects> projectList = projectController.getbyid("Lokesh@gmail.com");
	        assertEquals(2, projectList.size());
	        verify(projectService, times(1)).getByEmailId("Lokesh@gmail.com");
	
	        
	    }
	    @Test
	    public void getProjectByIdTestNegative()
	    {
	    	 List<Projects> list = new ArrayList<Projects>();
		        Projects project1 = new Projects(1,"Lokesh@gmail.com","projecrtname1","projectdescription","five years");
		        Projects project2 = new Projects(2,"Lokesh@gmail.com","projecrtname2","projectdescription","five years");
		        list.add(project1);
		        list.add(project2);
	        when(projectService.getByEmailId("Lokesh@gmail.com")).thenReturn(list);
	         
	        List<Projects> projectList = projectController.getbyid("Lokesh@gmail.com");
	        assertNotEquals(3, projectList.size());
	        verify(projectService, times(1)).getByEmailId("Lokesh@gmail.com");
	
	        
	    }
	    @Test
	    public void updateProjectTest() {
	    	Projects pro = new Projects(1,"Lokesh@gmail.com","projecrtname","projectdescription","five years");
	         
	        projectController.update(pro);
	         
	        verify(projectService, times(1)).updateProjet(pro);
	    	
	    }

	    @Test
	    public void deleteProjectTest() {
	    	Projects project1 = new Projects(1,"Lokesh@gmail.com","projecrtname1","projectdescription","five years");
	    	
	    	
	    	
	               projectController.deleteprojects(project1.getProjectId());
	               verify(projectService,times(1)).getOneProjects(1);
	               Projects project2= projectService.getOneProjects(1);
	               verify(projectService,times(1)).deleteproject(project2);
	               
	               
	    	
	    }
	    
}
