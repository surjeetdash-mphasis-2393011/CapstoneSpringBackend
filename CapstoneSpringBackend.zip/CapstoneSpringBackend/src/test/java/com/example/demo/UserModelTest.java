package com.example.demo;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.example.demo.model.Users;

public class UserModelTest {
	
	@Test
	public void TestgetUserId() {
		 Users users = new Users(1,"srujanagg@gmail.com","123*");
		 Users users1 = new Users(1,"srujanagg@gmail.com","123*");
		 assertEquals(users.getUserId(),users1.getUserId());
		
	}
	
	@Test
	public void TestSetUserId() {
		Users users = new Users(1,"srujanagg@gmail.com","123*");
		users.setUserId(2);
		 Users users1 = new Users(1,"srujanagg@gmail.com","123*");
		 users1.setUserId(2);
		 assertEquals(users.getUserId(),users1.getUserId()); 
		
	}
	
	@Test
	public void TestgetEmailId() {
		
		 Users users = new Users(1,"srujanagg@gmail.com","123*");
		 assertEquals("srujanagg@gmail.com",users.getEmailId());
		
	}
	@Test
	public void TestSetEmailId() {
		 Users users = new Users(1,"srujanagg@gmail.com","123*");
		 users.setEmailId("janagg@gmail.com");
		 assertEquals("janagg@gmail.com",users.getEmailId());
		
	}
	
	@Test
	public void TestgetPassword() {
		 Users users = new Users(1,"srujanagg@gmail.com","123*");
		 assertEquals("123*",users.getPassword());
	}
	
	@Test
	public void TestSetPassword() {
		Users users = new Users(1,"srujanagg@gmail.com","123*");
		users.setPassword("1234*");
		assertEquals("1234*",users.getPassword());
		
	}
	
	@Test
	public void TestToString() {
		Users users = new Users(1,"srujanagg@gmail.com","123*");
		String expected= "Users [userId=" + 1 + ", emailId=" + "srujanagg@gmail.com" + ", password=" + "123*" + "]";
		assertEquals(expected,users.toString());
		
	}
	@Test
	public void TestNonParametarizedConstructor() {
		Users users = new Users();
		String expectedPassword =null;
		assertEquals(expectedPassword,users.getPassword());
		
		
	}

}
