import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.example.demo.ProfileControllerTest;
import com.example.demo.ProfileModelTest;
import com.example.demo.ProfileServiceTest;
import com.example.demo.ProjectModelTest;
import com.example.demo.ProjectServiceTest;
import com.example.demo.ProjectsControllerTest;
import com.example.demo.UserControllerTest;
import com.example.demo.UserModelTest;
import com.example.demo.UserServiceTest;

@RunWith(Suite.class)
@SuiteClasses({ProfileControllerTest.class,ProjectsControllerTest.class,UserControllerTest.class,ProfileModelTest.class,ProjectModelTest.class,UserModelTest.class,ProjectServiceTest.class,ProfileServiceTest.class,UserServiceTest.class})
public class AllTestsSuite {

}
